package com.divyamotiwala.customerrelationshipmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.divyamotiwala.customerrelationshipmanagement.entity.Customer;
import com.divyamotiwala.customerrelationshipmanagement.service.CustomerManagementService;

@Controller
@RequestMapping("/customer")
public class CustomerManagementController {

	@Autowired
	CustomerManagementService service;
	
	@RequestMapping("/add")
	public String addCustomer(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "customer-form";
	}

	@RequestMapping("/delete")
	public String deleteCustomer(@RequestParam("id") int id) {
		service.deleteCustomer(id);
		return "redirect:/customer/list";
	}

	@RequestMapping("/update")
	public String updateCustomer(@RequestParam("id") int id, Model model) 
	{
		Customer customer = service.getCustomerById(id);
		model.addAttribute("customer", customer);
		return "customer-form";
	}

	@PostMapping("/save")
	public String saveCustomer(@RequestParam("id") int id, @RequestParam("firstname") String firstName,
			@RequestParam("lastname") String lastName, @RequestParam("email") String email) {
		Customer customer;
		if(id != 0) {
			customer = service.getCustomerById(id);
		}else {
			customer = new Customer();
		}
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmail(email);
		service.addCustomer(customer);
		return "redirect:/customer/list";
	}
	
	@RequestMapping("/list")
	public String getAllCustomers(Model model) {
		
		List<Customer> customerList = service.getAllCustomers();
		model.addAttribute("customerModel", customerList);
		
		return "customer-list";
	}
	
}
