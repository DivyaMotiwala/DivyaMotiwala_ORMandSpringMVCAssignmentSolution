package com.divyamotiwala.customerrelationshipmanagement.service;

import java.util.List;

import com.divyamotiwala.customerrelationshipmanagement.entity.Customer;

public interface CustomerManagementService {

	public void addCustomer(Customer customer);
	
	public int deleteCustomer(int id);
	
	public Customer getCustomerById(int id);
	
	public List<Customer> getAllCustomers();
	
}
