package com.divyamotiwala.customerrelationshipmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.divyamotiwala.customerrelationshipmanagement.entity.Customer;

@Service
@RequestMapping("/customer")
public class CustomerManagementServiceImpl implements CustomerManagementService {

	private SessionFactory factory;
	private Session session;

	@Autowired
	public CustomerManagementServiceImpl(SessionFactory factory) {
		this.factory = factory;
		try
		{
			session = factory.getCurrentSession();
		}
		catch(HibernateException he)
		{
			session = factory.openSession();
		}
	}
	
	@Override
	@Transactional
	public void addCustomer(Customer customer) {
		session.saveOrUpdate(customer);
	}

	@Override
	public int deleteCustomer(int id) {
		Customer customer = session.get(Customer.class, id);
		Transaction tx = session.beginTransaction();
		session.delete(customer);
		tx.commit();
		return customer.getCustomerId();
	}

	@Override
	public Customer getCustomerById(int id) {
		return session.get(Customer.class, id);
	}

	@Override
	public List<Customer> getAllCustomers() {
		@SuppressWarnings("unchecked")
		List<Customer> custList = (List<Customer>)session.createQuery("from Customer").list();
		return custList;
	}

}
